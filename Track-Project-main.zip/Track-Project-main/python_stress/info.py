EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_USE_TLS =True
EMAIL_HOST = 'smtp-mail.outlook.com'
EMAIL_HOST_USER = 'trackchamps@outlook.com'
EMAIL_HOST_PASSWORD = 'CPP!@#123'
EMAIL_PORT = 587